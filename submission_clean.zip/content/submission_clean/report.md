{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;\f1\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red255\green255\blue255;\red255\green255\blue255;\red221\green221\blue220;
\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c100000\c100000\c100000;\cssrgb\c100000\c100000\c99971\c0;\cssrgb\c89313\c89313\c88979;
\cssrgb\c0\c0\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs28 \cf2 \cb3 \expnd0\expndtw0\kerning0
Student Name: Kwok Tze Yu\
SID: 1155214366\
\
Step 2 Output:\
ROMEO:\
You before will be to love the disposion,\
Or take and my comfort such at he shall be there:\
And and sweet my father, when my father's of this blood,\
To will be mine the good latest in overtain.\
\
\
\
Step 3:\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 ========================================\
RUNNING MODEL: Layers=7, Heads=2\
========================================\
\
SUCCESS: Final Val Loss for 2 heads = 2.0992\
\
========================================\
RUNNING MODEL: Layers=7, Heads=3\
========================================\
\
SUCCESS: Final Val Loss for 3 heads = 2.0866\
\
========================================\
RUNNING MODEL: Layers=7, Heads=5\
========================================\
\
SUCCESS: Final Val Loss for 5 heads = 2.0918\
\
========================================\
RUNNING MODEL: Layers=7, Heads=7\
========================================\
\
SUCCESS: Final Val Loss for 7 heads = 2.0981\
\
--- All runs complete! ---\
Final Results for Plotting: \{2: 2.0992, 3: 2.0866, 5: 2.0918, 7: 2.0981\}\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 \
\
Step 4 data: \
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 length of dataset in characters: 1,978,211\
all the unique characters: 	\
 !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz\{|\}~\'a0\'a7\'e0\'ef\uc0\u8209 \'97\u9679 \u9986 \u10084 \
vocab size: 106\
train has 1,780,389 tokens\
val has 197,822 tokens\
\
\pard\pardeftab720\partightenfactor0
\cf2 \cb3 Step 4 Code sample: \
\pard\pardeftab720\partightenfactor0

\f1 \cf2 \cb3 \outl0\strokewidth0 \strokec5 Overriding: out_dir = out-code-generation\
number of parameters: 0.80M\
Loading meta from data/code_generation/meta.pkl...\
\
                   basicary = 0x32;\
                                      o->Z aray e if (                       // ust _number from\
                                                                                                                                                                                                                                                                                                                         \{Input_formate faters element +++w30^d */\
            \
---------------\
\
\
         \{\
          static const in = m_compace(alloc) && default;\
                const auto boolean array_t_t::back() = 0;\
              return get_number(input_format, numberPaject std::string:\
                      \{\
                                                                                                                       \{\
                                                                                                                                                            \
---------------\
\
                        <= 32S_* 28;\
                                                                                                                              4Starits return sax->parse_erse;\
                                                                                                                                                                                                                                                                                                                \
---------------\
\
                             return true;\
\
                                                                                                                                                                                                                                                                                                                                                                             oyqual.ements\
                                                                              \
---------------\
\
                                case 0xA5L:\
                                                                                                                                                               o^->write_stricarded.characte(urrent);\
                                                           \}\
\
            \{\
                    if (JSON_HROW(teranceted.s != 0x70;\
                             unf token_type::basic_json(nexpret_error);\
\
                                                     \
---------------\
\
\
         /// d`fine defrence to of w write a a re stat nin of\
       /// const bool anames pos doperates\
                  break;\
\
                                                                                  enable_if (NOLINT(number->index->begility(number_integer()) &&& sax->number_inder(const ::t:string->static_cbst<std::string_t& valN)\
    \{\
         JSON_TPG2000:\
       codeo, point = 0x0__202^-m)\
      return (du// 32his;\
      j.mwa_ = 0x4019 <u;\
        return index < 0;\
    \}\
   //\
---------------\
\
                                                                                                                                                                                                                                                                                                                                           if (JSON_HEDLEY_UNLIKELY(sub/aryte byte howes leacteiliteration\
          write_gn<= (get_token_type::preturn a = ddecble < <        ]                                   \
---------------\
\
                                                                                                                                                                                                                                              #64                                                                                                                                                                                                               \{\
                                                  \
---------------\
\
                                         oa->write_character(to_char_type[0]_`msgp, "clang: "nullptr)\
                                    connt, : number_unsigned());\
                                  return token.message_string(onles)\
                                                                                          return false;ase, m_data.m_type::max);\
                                                                                                       end_ // memment objects afx nor \
---------------\
\
                                    \{\
                               return talse;\
                        \{\
                        // array iterate fites the JSON expositions\
                                                                                                      && \\\
                                                                                                                                                   case for_t::strin'\\"CBseT639>=" // NOLINT(cpptrore_trkey.size()) // N\
---------------\
\pard\pardeftab720\partightenfactor0

\f0 \cf2 \cb3 \outl0\strokewidth0 \
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
\
}